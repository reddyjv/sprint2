import { useEffect, useState } from 'react';
import axios from 'axios';
import * as XLSX from 'xlsx';
import './styles.css';
import { useNavigate } from 'react-router';

const CustomerList = () => {
  const [customers, setCustomers] = useState([]);
  const [searchInput, setSearchInput] = useState('');
  const [filteredCustomers, setFilteredCustomers] = useState([]);
  const navigate = useNavigate();
  const [showModal, setShowModal] = useState(false);
  const [selectedCustomer, setSelectedCustomer] = useState(null);
  const [showSuccess, setShowSuccess] = useState(false);


  const fetchCustomers = () => {
    axios.get('http://localhost:5000/api/customers')
      .then(res => {
        setCustomers(res.data);
        setFilteredCustomers(res.data);
      })
      .catch(err => console.error(err));
  };

  useEffect(() => {
    fetchCustomers();
  }, []);

  const handleSearch = () => {
    const filtered = customers.filter(cust =>
      cust.cphone.toString().includes(searchInput) ||
      cust.cname.toLowerCase().includes(searchInput.toLowerCase())
    );
    setFilteredCustomers(filtered);
  };


  const filtered = customers.filter(cust =>
    cust.cphone.toString().includes(searchInput)
  );

  const handleDelete = async (id) => {
    if (window.confirm('Are you sure you want to delete this customer?')) {
      try {
        await axios.delete(`http://localhost:5000/api/customers/delete/${id}`);
        fetchCustomers();
      } catch (error) {
        console.error('Delete failed:', error);
      }
    }
  };

  const handleUpdate = (customerId) => {
    const customer = customers.find(c => c.customerId === customerId);
    setSelectedCustomer({ ...customer });
    setShowModal(true);
  };
  const handleModalSubmit = async () => {
    try {
      console.log("Updated")
      await axios.put(`http://localhost:5000/api/customers/updatecustomer/${selectedCustomer.customerId}`, selectedCustomer);
      setShowModal(false);
      fetchCustomers();
      setShowSuccess(true);
      setTimeout(() => setShowSuccess(false), 2000);
    } catch (error) {
      console.error('Update failed:', error);
    }
  };


  const downloadExcel = () => {
    const worksheet = XLSX.utils.json_to_sheet(filteredCustomers);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Customers');
    XLSX.writeFile(workbook, 'CustomerList.xlsx');
  };

  return (
    <>
      {selectedCustomer && (
        <div className={`modal fade ${showModal ? 'show d-block' : ''}`} tabIndex="-1" style={{ backgroundColor: 'rgba(0,0,0,0.4)' }}>
          <div className="modal-dialog modal-lg">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">Update Customer</h5>
                <button type="button" className="btn-close" onClick={() => setShowModal(false)}></button>
              </div>
              <div className="modal-body">
                <form className="container">
                  <div className="row mb-3">
                    <div className="col-md-6">
                      <label className="form-label">Customer ID</label>
                      <input type="text" className="form-control form-control-sm" value={selectedCustomer.customerId} disabled />
                    </div>
                    <div className="col-md-6">
                      <label className="form-label">Name</label>
                      <input type="text" className="form-control form-control-sm" value={selectedCustomer.cname}
                        onChange={(e) => setSelectedCustomer({ ...selectedCustomer, cname: e.target.value })} />
                    </div>
                  </div>

                  <div className="row mb-3">
                    <div className="col-md-6">
                      <label className="form-label">Phone</label>
                      <input type="text" className="form-control form-control-sm" value={selectedCustomer.cphone}
                        onChange={(e) => setSelectedCustomer({ ...selectedCustomer, cphone: e.target.value })} />
                    </div>
                    <div className="col-md-6">
                      <label className="form-label">Email</label>
                      <input type="email" className="form-control form-control-sm" value={selectedCustomer.mailId}
                        onChange={(e) => setSelectedCustomer({ ...selectedCustomer, mailId: e.target.value })} />
                    </div>
                  </div>

                  <div className="row mb-3">
                    <div className="col-md-6">
                      <label className="form-label">Address</label>
                      <input type="text" className="form-control form-control-sm" value={selectedCustomer.address}
                        onChange={(e) => setSelectedCustomer({ ...selectedCustomer, address: e.target.value })} />
                    </div>
                    <div className="col-md-6">
                      <label className="form-label">Category</label>
                      <select
                        className="form-select form-select-sm"
                        value={selectedCustomer.category}
                        onChange={(e) => setSelectedCustomer({ ...selectedCustomer, category: e.target.value })}
                      >
                        <option value="">-- Select Category --</option>
                        <option value="Wholesaler">Wholesaler</option>
                        <option value="Retailer">Retailer</option>
                        <option value="Premium">Premium</option>
                      </select>
                    </div>

                  </div>
                </form>
              </div>
              <div className="modal-footer">
                <button className="btn btn-secondary btn-sm" onClick={() => setShowModal(false)}>Cancel</button>
                <button className="btn btn-success btn-sm" onClick={handleModalSubmit}>Update</button>
              </div>
            </div>
          </div>
        </div>
      )}
      <div className="customer-table-wrapper container mt-4">
        <nav className="navbar navbar-expand-lg navbar-dark bg-success rounded mb-4 px-4">
          <span className="navbar-brand">👥 Customer Manager</span>
        </nav>

        <div className="d-flex flex-wrap justify-content-between align-items-center mb-4 gap-3">
          <div className="d-flex gap-2 flex-grow-1">
            <input
              type="text"
              className="form-control search-input"
              placeholder="Search by phone number or name"
              value={searchInput}
              onChange={(e) => {
                setSearchInput(e.target.value);
                const val = e.target.value;
                const filtered = customers.filter(cust =>
                  cust.cphone.toString().includes(val) ||
                  cust.cname.toLowerCase().includes(val.toLowerCase())
                );
                setFilteredCustomers(filtered);
              }}
            />
            <button className="btn btn-outline-success" onClick={handleSearch}>
              Search
            </button>
          </div>

          <button className="btn btn-outline-primary" onClick={downloadExcel}>
            Download Excel
          </button>
        </div>

        <div className="table-responsive rounded shadow-sm">
          <table className="table table-bordered table-hover table-light text-center">
            <thead className="table-dark">
              <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Phone</th>
                <th>Email</th>
                <th>Address</th>
                <th>Type</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {filteredCustomers.length > 0 ? (
                filteredCustomers.map(cust => (
                  <tr key={cust.customerId}>
                    <td>{cust.customerId}</td>
                    <td>{cust.cname}</td>
                    <td>{cust.cphone}</td>
                    <td>{cust.mailId}</td>
                    <td>{cust.address}</td>
                    <td>{cust.category}</td>
                    <td>
                      <button style={{ borderRadius: '10px' }} className="btn btn-sm btn-warning me-2" onClick={() => handleUpdate(cust.customerId)}>
                        Update
                      </button>
                      <button style={{ borderRadius: '10px' }} className="btn btn-sm btn-danger" onClick={() => handleDelete(cust.customerId)}>
                        Delete
                      </button>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="7" className="text-center">No customers found.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        <div className="mt-4 text-end">
          <h5 className="text-muted">
            <strong>Total Registered Customers:</strong> {filteredCustomers.length}
          </h5>
        </div>
      </div>
      {showSuccess && (
        <div
          className="position-fixed top-0 start-50 translate-middle-x mt-3 px-4 py-2 rounded shadow"
          style={{
            backgroundColor: '#00e600',
            color: '#ffffff',
            zIndex: 1050,
            transition: 'transform 0.5s ease-out',
            animation: 'slideDown 0.5s ease forwards'
          }}
        >
          Customer Id updated Successfully!
        </div>
      )}

    </>
  );
};

export default CustomerList;
