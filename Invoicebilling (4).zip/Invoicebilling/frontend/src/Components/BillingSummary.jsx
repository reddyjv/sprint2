import React, { useState } from 'react';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import axios from 'axios';

const BillingSummary = ({ products, customer, onReset }) => {
  const [invoiceMeta, setInvoiceMeta] = useState({ invoiceNumber: '', date: '', time: '' });
  const [specialDiscountEnabled, setSpecialDiscountEnabled] = useState(false);
  const [specialDiscountPercent, setSpecialDiscountPercent] = useState(0);
  const [paymentMode, setPaymentMode] = useState('');
  const [cashReceived, setCashReceived] = useState('');
  const [changeToBeReturned, setChangeToBeReturned] = useState('');

  let totalPrice = 0, totalDiscount = 0, totalGST = 0, finalAmount = 0;

  const summaryData = products.map((product) => {
    const qty = parseFloat(product.qty) || 0;
    const saleprice = parseFloat(product.saleprice) || 0;
    const discount = parseFloat(product.discount) || 0;
    const GST = parseFloat(product.GST) || 0;

    const baseAmount = qty * saleprice;
    const discountAmount = baseAmount * (discount / 100);
    const discounted = baseAmount - discountAmount;
    const gstAmount = discounted * (GST / 100);
    const total = discounted + gstAmount;

    totalPrice += baseAmount;
    totalDiscount += discountAmount;
    totalGST += gstAmount;
    finalAmount += total;

    return {
      pname: product.pname,
      qty,
      saleprice: saleprice.toFixed(2),
      discount: discountAmount.toFixed(2),
      gst: gstAmount.toFixed(2),
      total: total.toFixed(2),
    };
  });

  // Apply Special Discount
  const specialDiscountAmount = specialDiscountEnabled
    ? (finalAmount * parseFloat(specialDiscountPercent || 0)) / 100
    : 0;

  const totalAfterSpecialDiscount = finalAmount - specialDiscountAmount;
  const totalDiscountWithSpecial = totalDiscount + specialDiscountAmount;

  // Calculate Change
  const handleCashReceivedChange = (e) => {
    const received = parseFloat(e.target.value) || 0;
    setCashReceived(e.target.value);

    const change = received - totalAfterSpecialDiscount;
    setChangeToBeReturned(change > 0 ? change.toFixed(2) : '0.00');
  };

  const handlePrint = async () => {
    try {
      const res = await axios.post('http://localhost:5000/api/invoices/createinvoice', {
        customer,
        items: summaryData,
        totals: {
          totalPrice,
          totalDiscount: totalDiscountWithSpecial,
          totalGST,
          finalAmount: totalAfterSpecialDiscount,
          specialDiscount: specialDiscountAmount,
          paymentMode,
          cashReceived: paymentMode === 'Cash' ? cashReceived : null,
          changeToBeReturned: paymentMode === 'Cash' ? changeToBeReturned : null
        }
      });

      const { invoiceNumber, date, time } = res.data;
      setInvoiceMeta({ invoiceNumber, date, time });

      if (paymentMode === 'credit') {
        console.log("Hello");
        await axios.put(`http://localhost:5000/api/customers/updateWallet/${customer.customerId}`, {
          amount: totalAfterSpecialDiscount
        });
      }

      const doc = new jsPDF();
      doc.setFont('times', 'normal');

      // Title
      doc.setFontSize(22);
      doc.setTextColor(33, 150, 243);
      doc.text('Billing Summary', 14, 15);

      // Invoice Box
      doc.setTextColor(0);
      doc.setFontSize(12);
      doc.setDrawColor(200, 200, 200);  // Light grey border
      doc.roundedRect(12, 20, 185, 25, 3, 3);
      doc.text(`Invoice No: ${invoiceNumber}`, 14, 28);
      doc.text(`Date: ${date}`, 130, 28);
      doc.text(`Time: ${time}`, 130, 36);

      // Customer Details Box
      doc.setFontSize(13);
      doc.setTextColor(0, 102, 204);
      doc.text('Customer Details:', 14, 52);

      doc.setFontSize(11);
      doc.setTextColor(0);
      doc.setDrawColor(200, 200, 200);
      doc.roundedRect(12, 55, 185, 30, 3, 3);

      doc.text(`Name: ${customer.cname || 'N/A'}`, 14, 63);
      doc.text(`Phone: ${customer.cphone || 'N/A'}`, 14, 70);
      doc.text(`Email: ${customer.mailId || 'N/A'}`, 110, 63);
      doc.text(`Address: ${customer.address || 'N/A'}`, 110, 70);

      // Product Table
      autoTable(doc, {
        startY: 95,
        head: [['Product', 'Qty', 'Price (Rs)', 'Discount (%)', 'GST (%)', 'Subtotal (Rs)']],
        body: summaryData.map(item => [
          item.pname,
          item.qty.toString(),
          item.saleprice,
          item.discount,
          item.gst,
          item.total
        ]),
        styles: {
          font: 'times',
          fontSize: 11,
          halign: 'center',
          valign: 'middle'
        },
        headStyles: {
          fillColor: [33, 150, 243],
          textColor: 255,
          fontSize: 12,
          halign: 'center'
        },
        theme: 'grid',
        columnStyles: {
          0: { halign: 'left' }
        }
      });

      // Totals
      const finalY = doc.lastAutoTable.finalY + 10;
      doc.setFontSize(12);
      doc.setTextColor(0);

      doc.text(`Total Price (Before Discount & GST): Rs. ${totalPrice.toFixed(2)}`, 14, finalY);
      doc.text(`Total Discount: Rs. ${totalDiscount.toFixed(2)}`, 14, finalY + 7);
      doc.text(`Special Discount: Rs. ${specialDiscountAmount.toFixed(2)}`, 14, finalY + 14);
      doc.text(`Total GST: Rs. ${totalGST.toFixed(2)}`, 14, finalY + 21);
      doc.text(`Payment Mode: ${paymentMode}`, 14, finalY + 28);

      if (paymentMode === 'Cash') {
        doc.text(`Cash Received: Rs. ${cashReceived}`, 14, finalY + 35);
        doc.text(`Change Returned: Rs. ${changeToBeReturned}`, 14, finalY + 42);
      }

      // Final Bill
      doc.setFontSize(14);
      doc.setTextColor(0, 102, 204);
      doc.setFont('times', 'bold');
      doc.text(`Final Bill Amount: Rs. ${totalAfterSpecialDiscount.toFixed(2)}`, 14, finalY + 50);

      // Save
      await doc.save(`${invoiceNumber}_Billing_Summary.pdf`);

      const pdfBlob = doc.output('blob');
      const formData = new FormData();
      formData.append('pdf', pdfBlob, `${invoiceNumber}_Billing_Summary.pdf`);
      formData.append('email', customer.mailId);

      await axios.post('http://localhost:5000/send-invoice', formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });
      if (onReset) onReset();



    } catch (error) {
      console.error('Error generating invoice:', error);
    }
  };

  return (
    <div className="mt-4 p-3 border rounded" style={{ backgroundColor: '#eaf4ff' }}>
      <h5>🧾 Billing Summary</h5>
      <ul className="list-group mb-2">
        {summaryData.map((item, idx) => (
          <li key={idx} className="list-group-item d-flex justify-content-between flex-column">
            <div>
              <strong>{item.pname}</strong> (Qty: {item.qty})<br />
              ₹{item.saleprice} each | Discount: ₹{item.discount} | GST: ₹{item.gst}
            </div>
            <div>
              Subtotal: ₹{item.total}
            </div>
          </li>
        ))}
      </ul>

      <div className="form-check mb-2">
        <input
          className="form-check-input"
          type="checkbox"
          checked={specialDiscountEnabled}
          onChange={() => setSpecialDiscountEnabled(!specialDiscountEnabled)}
          id="specialDiscount"
        />
        <label className="form-check-label" htmlFor="specialDiscount">
          Apply Special Discount
        </label>
      </div>

      {specialDiscountEnabled && (
        <div className="mb-2">
          <label htmlFor="specialDiscountPercent">Enter Special Discount %:</label>
          <input
            type="number"
            className="form-control"
            id="specialDiscountPercent"
            value={specialDiscountPercent}
            onChange={(e) => setSpecialDiscountPercent(e.target.value)}
            min="0"
            max="100"
          />
        </div>
      )}

      <div className="mb-2">
        <label htmlFor="paymentMode">Payment Mode:</label>
        <select
          className="form-select"
          id="paymentMode"
          required
          value={paymentMode}
          onChange={(e) => setPaymentMode(e.target.value)}
        >
          <option value="">-- Select Payment Mode --</option>
          <option value="Cash">Cash</option>
          <option value="Card">Card</option>
          <option value="UPI">UPI</option>
          <option value="credit">Credit</option>
        </select>
      </div>

      {paymentMode === 'Cash' && (
        <div className="mb-2">
          <label htmlFor="cashReceived">Cash Received:</label>
          <input
            type="number"
            className="form-control"
            id="cashReceived"
            value={cashReceived}
            onChange={handleCashReceivedChange}
            min="0"
          />
          <div className="mt-1">
            <strong>Change to Return:</strong> ₹{changeToBeReturned || '0.00'}
          </div>
        </div>
      )}

      <div className="text-end">
        <p><strong>Total Price:</strong> ₹{totalPrice.toFixed(2)}</p>
        <p><strong>Total Discount:</strong> ₹{totalDiscount.toFixed(2)}</p>
        {specialDiscountEnabled && (
          <p><strong>Special Discount:</strong> ₹{specialDiscountAmount.toFixed(2)}</p>
        )}
        <p><strong>Total GST:</strong> ₹{totalGST.toFixed(2)}</p>
        <h5><strong>Final Bill Amount:</strong> ₹{totalAfterSpecialDiscount.toFixed(2)}</h5>
        <button className="btn btn-primary mt-3" disabled={!paymentMode} onClick={handlePrint}>
          🖨️ Print & Save Invoice
        </button>
      </div>
    </div>
  );
};

export default BillingSummary;
