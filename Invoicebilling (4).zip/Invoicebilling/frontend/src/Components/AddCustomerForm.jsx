import { useState } from 'react';
import axios from 'axios';
import 'bootstrap/dist/css/bootstrap.min.css';

const AddCustomerForm = () => {
  const [formData, setFormData] = useState({
    cname: '',
    address: '',
    mailId: '',
    cphone: '',
    category: '',
    walletBal:''
  });

  const [errors, setErrors] = useState({});
  const [formValid, setFormValid] = useState({
    cname: false,
    address: false,
    mailId: false,
    cphone: false,
    category: false,
    walletBal:false
  });

  const [buttonActive, setButtonActive] = useState(false);
  const [success, setSuccess] = useState('');
  const [error, setError] = useState('');

  const validate = (name, value) => {
    let error = '';
    let cnameValid = formValid.cname;
    let addressValid = formValid.address;
    let mailIdValid = formValid.mailId;
    let cphoneValid = formValid.cphone;
    let categoryValid = formValid.category;
    let walletBalValid=formValid.walletBal

    switch (name) {
      case 'cname':
        cnameValid = value.trim() !== '';
        error = cnameValid ? '' : 'Customer name is required.';
        break;
      case 'address':
        addressValid = value.trim() !== '';
        error = addressValid ? '' : 'Address is required.';
        break;
      case 'mailId':
        mailIdValid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
        error = value.trim() === '' ? 'Email is required.' : (!mailIdValid ? 'Invalid email format.' : '');
        break;
      case 'cphone':
        cphoneValid = /^\d{10}$/.test(value);
        error = value.trim() === '' ? 'Phone number is required.' : (!cphoneValid ? 'Phone must be 10 digits.' : '');
        break;
      case 'category':
        categoryValid = value.trim() !== '';
        error = categoryValid ? '' : 'Category is required.';
        break;
      case 'walletBal':
        walletBalValid = value.trim() !== '';
        error = walletBalValid ? '' : 'Wallet Balance is required.';
        break;
      default:
        break;
    }

    setErrors((prev) => ({ ...prev, [name]: error }));

    setFormValid({
      cname: cnameValid,
      address: addressValid,
      mailId: mailIdValid,
      cphone: cphoneValid,
      category: categoryValid,
      walletBal:walletBalValid
    });

    if (cnameValid && addressValid && mailIdValid && cphoneValid && categoryValid && walletBalValid) {
      setButtonActive(true);
    } else {
      setButtonActive(false);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;

    setFormData((prev) => ({
      ...prev,
      [name]: value
    }));

    validate(name, value);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post('http://localhost:5000/api/customers/add', formData);
      setSuccess(`✅ Customer added with ID: ${res.data.customer.customerId}`);
      setFormData({ cname: '', address: '', mailId: '', cphone: '', category: '',walletBal:'' });
      setErrors({});
      setFormValid({ cname: false, address: false, mailId: false, cphone: false, category: false,walletBal:false });
      setButtonActive(false);
      setTimeout(() => setSuccess(''), 2000);
    } catch (err) {
      if (err.response?.status === 500) {
        setError('Customer is already Registered');
      } else {
        setError(err.message);
      }
    }
  };
  return (
    <div className="container mt-5">
      <div className="card shadow-lg p-4 border-0 rounded-4" style={{ maxWidth: '720px', margin: '0 auto', background: '#f9fdfc' }}>
        <h3 className="text-center text-white py-3 rounded-top" style={{ background: 'linear-gradient(to right, #6a11cb, #2575fc)' }}>
          👤 Add New Customer
        </h3>
        {success && <div className="alert alert-success mt-3">{success}</div>}
        {error && <div className="alert alert-danger mt-3">{error}</div>}
        <form onSubmit={handleSubmit}>
          <div className="form-group my-2">
            <label>Customer Name</label>
            <input
              type="text"
              name="cname"
              value={formData.cname}
              onChange={handleChange}
              placeholder="Enter customer name"
              className={`form-control ${errors.cname ? 'is-invalid' : ''}`}
            />
            {errors.cname && <div className="invalid-feedback">{errors.cname}</div>}
          </div>
          <div className="form-group my-2">
            <label>Address</label>
            <input
              type="text"
              name="address"
              value={formData.address}
              onChange={handleChange}
              placeholder="Enter address"
              className={`form-control ${errors.address ? 'is-invalid' : ''}`}
            />
            {errors.address && <div className="invalid-feedback">{errors.address}</div>}
          </div>

          <div className="form-group my-2">
            <label>Email</label>
            <input
              type="email"
              name="mailId"
              value={formData.mailId}
              onChange={handleChange}
              placeholder="Enter email address"
              className={`form-control ${errors.mailId ? 'is-invalid' : ''}`}
            />
            {errors.mailId && <div className="invalid-feedback">{errors.mailId}</div>}
          </div>

          <div className="form-group my-2">
            <label>Phone Number</label>
            <input
              type="text"
              name="cphone"
              value={formData.cphone}
              onChange={handleChange}
              placeholder="Enter 10-digit phone number"
              className={`form-control ${errors.cphone ? 'is-invalid' : ''}`}
            />
            {errors.cphone && <div className="invalid-feedback">{errors.cphone}</div>}
          </div>

          <div className="form-group my-2">
            <label>Customer Type</label>
            <select
              name="category"
              value={formData.category}
              onChange={handleChange}
              className={`form-control ${errors.category ? 'is-invalid' : ''}`}
            >
              <option value="">-- Select Type --</option>
              <option value="Retail">Retail</option>
              <option value="Wholesale">Wholesale</option>
              <option value="Corporate">Corporate</option>
            </select>
            {errors.category && <div className="invalid-feedback">{errors.category}</div>}
          </div>

          <div className="form-group my-2">
            <label>Enter Wallet Balance:</label>
            <input
              type="text"
              name="walletBal"
              value={formData.walletBal}
              onChange={handleChange}
              placeholder="Enter Wallet Balance"
              className={`form-control ${errors.walletBal ? 'is-invalid' : ''}`}
            />
            {errors.walletBal && <div className="invalid-feedback">{errors.walletBal}</div>}
          </div>

          <button type="submit" className="btn btn-primary mt-3 w-100" disabled={!buttonActive}>
            Add Customer
          </button>
        </form>
      </div>
    </div>
  );
};

export default AddCustomerForm;
