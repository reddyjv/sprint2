import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Pagination } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap-icons/font/bootstrap-icons.css';

const categories = ['Groceries', 'Stationery', 'Beauty Products', 'Electronics', 'Clothing'];
const gstRates = [5, 12, 18, 28];

export default function ManageProducts() {
  const [products, setProducts] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState('');
  const [selectedGst, setSelectedGst] = useState('');
  const [priceRange, setPriceRange] = useState({ min: '', max: '' });
  const [sortAsc, setSortAsc] = useState(true);
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 8;

  useEffect(() => {
    fetchProducts();
  }, []);

  const fetchProducts = async () => {
    try {
      const res = await axios.get('http://localhost:5000/api/products');
      setProducts(res.data);
    } catch (err) {
      console.error('Error fetching products:', err);
    }
  };

  const clearFilters = () => {
    setSelectedCategory('');
    setSelectedGst('');
    setPriceRange({ min: '', max: '' });
  };

  const filteredProducts = products
    .filter((product) => {
      const matchCat = selectedCategory ? product.category === selectedCategory : true;
      const matchGst = selectedGst ? product.GST.toString() === selectedGst : true;
      const matchPrice =
        (priceRange.min ? product.saleprice >= parseFloat(priceRange.min) : true) &&
        (priceRange.max ? product.saleprice <= parseFloat(priceRange.max) : true);
      return matchCat && matchGst && matchPrice;
    })
    .sort((a, b) => {
      const nameA = a.pname.toLowerCase();
      const nameB = b.pname.toLowerCase();
      return sortAsc ? nameA.localeCompare(nameB) : nameB.localeCompare(nameA);
    });

  // Pagination logic
  const indexOfLastProduct = currentPage * itemsPerPage;
  const indexOfFirstProduct = indexOfLastProduct - itemsPerPage;
  const currentProducts = filteredProducts.slice(indexOfFirstProduct, indexOfLastProduct);
  const totalPages = Math.ceil(filteredProducts.length / itemsPerPage);

  const paginate = (pageNumber) => setCurrentPage(pageNumber);

  return (
    <div className="container-fluid">
      <div className="row">
        {/* Sidebar Filters */}
        <div className="col-md-2 p-3 bg-light min-vh-100 shadow-sm">
          <h5 className="mb-3"><i className="bi bi-funnel-fill me-2"></i>Filters</h5>

          <div className="mb-3">
            <label className="form-label"><strong>Category</strong></label>
            <select
              className="form-select"
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
            >
              <option value="">All Categories</option>
              {categories.map((cat, i) => (
                <option key={i} value={cat}>{cat}</option>
              ))}
            </select>
          </div>

          <div className="mb-3">
            <label className="form-label"><strong>Price Range</strong></label>
            <div className="d-flex gap-2">
              <input
                type="number"
                className="form-control"
                placeholder="Min"
                value={priceRange.min}
                onChange={(e) => setPriceRange({ ...priceRange, min: e.target.value })}
              />
              <input
                type="number"
                className="form-control"
                placeholder="Max"
                value={priceRange.max}
                onChange={(e) => setPriceRange({ ...priceRange, max: e.target.value })}
              />
            </div>
          </div>

          <div className="mb-3">
            <label className="form-label"><strong>GST</strong></label>
            <select
              className="form-select"
              value={selectedGst}
              onChange={(e) => setSelectedGst(e.target.value)}
            >
              <option value="">All GST Rates</option>
              {gstRates.map((gst, i) => (
                <option key={i} value={gst}>{gst}%</option>
              ))}
            </select>
          </div>

          <button className="btn btn-outline-danger w-100 mt-3" onClick={clearFilters}>
            <i className="bi bi-x-circle me-1"></i>Clear Filters
          </button>
        </div>

        {/* Main Table */}
        <div className="col-md-10 p-4">
          <div className="d-flex justify-content-between align-items-center mb-3">
            <h3><i className="bi bi-box-seam me-2"></i>Manage Products</h3>
            <button
              className="btn btn-outline-primary"
              onClick={() => setSortAsc(!sortAsc)}
            >
              Sort by Name {sortAsc ? <i className="bi bi-sort-alpha-down"></i> : <i className="bi bi-sort-alpha-up"></i>}
            </button>
          </div>

          <div className="table-responsive ">
            <table className="table table-striped table-bordered align-middle">
              <thead className="table-info">
                <tr>
                  <th><i className="bi bi-hash"></i> ID</th>
                  <th><i className="bi bi-box"></i> Name</th>
                  <th><i className="bi bi-currency-rupee"></i> Sale Price</th>
                  <th><i className="bi bi-currency-rupee"></i>MRP</th>
                  <th>Stock</th>
                  <th>GST %</th>
                  <th>Batch No</th>
                  <th>Category</th>
                </tr>
              </thead>
              <tbody>
                {currentProducts.length > 0 ? (
                  currentProducts.map((prod) => (
                    <tr
                      key={prod.productId}
                    >
                      <td>{prod.productId}</td>
                      <td>{prod.pname}</td>
                      <td>₹{prod.saleprice}</td>
                      <td>₹{prod.MRP}</td>
                      <td>{prod.stock}</td>
                      <td>{prod.GST}%</td>
                      <td>{prod.batchNo}</td>
                      <td>{prod.category}</td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan="8" className="text-center text-muted">No products found.</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          {/* Pagination Controls */}
          <div className="d-flex justify-content-between align-items-center mt-3">
            <div><strong>Total Filtered: {filteredProducts.length}</strong></div>
            <Pagination>
              {[...Array(totalPages).keys()].map((num) => (
                <Pagination.Item
                  key={num + 1}
                  active={num + 1 === currentPage}
                  onClick={() => paginate(num + 1)}
                >
                  {num + 1}
                </Pagination.Item>
              ))}
            </Pagination>
            <div><strong>All Products: {products.length}</strong></div>
          </div>
        </div>
      </div>
    </div>
  );
}
