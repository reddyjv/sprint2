import React, { useEffect, useState } from 'react';
import axios from 'axios';

const Dashboard = () => {
    const [customerCount, setCustomerCount] = useState(0);
    const [dueBills] = useState(5); // placeholder
    const [productsCount, setProductsCount] = useState(0);
    const [todaySales, setTodaySales] = useState(0);
    const [selectedMenu, setSelectedMenu] = useState('Home');

    useEffect(() => {
      axios.get('http://localhost:5000/api/customers')
        .then(response => {
          setCustomerCount(response.data.count || response.data.length || 0);
        })
        .catch(error => console.error('Error fetching customer count:', error));

      axios.get('http://localhost:5000/api/products')
        .then(response => {
          setProductsCount(response.data.length || 0);
        })
        .catch(error => console.error('Error fetching products count:', error));

      axios.get('http://localhost:5000/api/invoices/totals/today')
        .then(response => {
          setTodaySales(response.data.totalSales || 0);
        })
        .catch(error => console.error('Error fetching today sales:', error));
    }, []);

    // Colors for cards
    const cardColors = [
      'linear-gradient(135deg, #4a90e2 0%, #6a5acd 100%)', // blue to purple
      'linear-gradient(135deg, #7b8d93 0%, #4b6cb7 100%)', // gray to blue
      'linear-gradient(135deg, #d9822b 0%, #e74c3c 100%)', // orange to red
      'linear-gradient(135deg, #50b948 0%, #27ae60 100%)'  // green to darker green
    ];

    // Styles
    const styles = {
      container: {
        display: 'flex',
        minHeight: '100vh',
        fontFamily: "'Inter', -apple-system, BlinkMacSystemFont, sans-serif",
        backgroundColor: '#f5f7fa',
        overflow: 'hidden'
      },
      sidebar: {
        width: '240px',
        backgroundColor: '#2c3e50',
        color: '#ecf0f1',
        paddingTop: '40px',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        boxShadow: '2px 0 15px rgba(0,0,0,0.1)',
        userSelect: 'none',
        position: 'fixed',
        height: '100vh',
        zIndex: 100
      },
      sidebarTitle: {
        fontSize: '24px',
        fontWeight: '700',
        marginBottom: '40px',
        letterSpacing: '1px',
        color: '#ecf0f1',
        display: 'flex',
        alignItems: 'center',
        gap: '10px'
      },
      sidebarItem: (active) => ({
        width: '85%',
        padding: '14px 20px',
        marginBottom: '12px',
        borderRadius: '8px',
        cursor: 'pointer',
        display: 'flex',
        alignItems: 'center',
        gap: '14px',
        fontSize: '15px',
        fontWeight: active ? '600' : '500',
        color: active ? '#ffffff' : '#bdc3c7',
        backgroundColor: active ? 'rgba(255,255,255,0.1)' : 'transparent',
        transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
        userSelect: 'none',
        '&:hover': {
          backgroundColor: 'rgba(255,255,255,0.1)',
          transform: 'translateX(5px)'
        }
      }),
      sidebarIcon: {
        fontSize: '20px',
        transition: 'all 0.3s ease'
      },
      mainContent: {
        flex: 1,
        display: 'flex',
        flexDirection: 'column',
        overflowY: 'auto',
        backgroundColor: '#f8fafc',
        marginLeft: '240px',
        width: 'calc(100% - 240px)'
      },
      navbar: {
        height: '80px',
        backgroundColor: '#ffffff',
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        padding: '0 40px',
        fontWeight: '600',
        userSelect: 'none',
        borderBottom: '1px solid #e0e0e0',
        fontSize: '20px',
        color: '#34495e',
        boxShadow: '0 2px 10px rgba(0,0,0,0.03)',
        position: 'sticky',
        top: 0,
        zIndex: 10
      },
      navbarUser: {
        display: 'flex',
        alignItems: 'center',
        gap: '16px',
        color: '#34495e',
        fontSize: '15px',
        fontWeight: '600'
      },
      userAvatar: {
        width: '40px',
        height: '40px',
        borderRadius: '50%',
        backgroundColor: '#4a90e2',
        color: 'white',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        fontWeight: 'bold',
        fontSize: '16px'
      },
      logoutBtn: {
        padding: '8px 20px',
        borderRadius: '20px',
        border: 'none',
        backgroundColor: '#4a90e2',
        color: '#fff',
        fontWeight: '600',
        fontSize: '14px',
        cursor: 'pointer',
        transition: 'all 0.3s ease',
        userSelect: 'none',
        boxShadow: '0 2px 10px rgba(74, 144, 226, 0.3)',
        display: 'flex',
        alignItems: 'center',
        gap: '8px',
        '&:hover': {
          backgroundColor: '#3a7bc8',
          transform: 'translateY(-2px)',
          boxShadow: '0 4px 12px rgba(74, 144, 226, 0.4)'
        }
      },
      cardsRow: {
        padding: '30px 40px',
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))',
        gap: '24px',
        justifyContent: 'center'
      },
      card: (index) => ({
        background: cardColors[index],
        color: 'white',
        padding: '24px',
        borderRadius: '16px',
        boxShadow: '0 10px 20px rgba(0,0,0,0.1)',
        cursor: 'default',
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'space-between',
        userSelect: 'none',
        transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
        fontWeight: '700',
        fontSize: '18px',
        letterSpacing: '0.5px',
        minHeight: '180px',
        '&:hover': {
          transform: 'translateY(-5px)',
          boxShadow: '0 15px 30px rgba(0,0,0,0.15)'
        }
      }),
      cardIcon: {
        fontSize: '36px',
        marginBottom: '16px',
        opacity: 0.9,
        alignSelf: 'flex-end'
      },
      cardContent: {
        display: 'flex',
        flexDirection: 'column'
      },
      cardTitle: {
        fontSize: '16px',
        marginBottom: '8px',
        fontWeight: '500',
        opacity: 0.9,
        letterSpacing: '0.5px'
      },
      cardCount: {
        fontSize: '32px',
        fontWeight: '700',
        lineHeight: 1.2,
        margin: '8px 0'
      },
      cardSubtitle: {
        fontSize: '14px',
        opacity: 0.8,
        fontWeight: '400'
      },
      managementSection: {
        padding: '20px 40px 40px',
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))',
        gap: '32px',
        backgroundColor: '#f9fafb',
        borderTop: '1px solid #e2e2e2'
      },
      sectionTitle: {
        fontSize: '20px',
        fontWeight: '600',
        color: '#2c3e50',
        margin: '0 40px 20px',
        paddingTop: '20px'
      },
      managementCard: {
        backgroundColor: '#fff',
        borderRadius: '16px',
        boxShadow: '0 5px 15px rgba(0,0,0,0.05)',
        overflow: 'hidden',
        display: 'flex',
        flexDirection: 'column',
        userSelect: 'none',
        transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
        '&:hover': {
          transform: 'translateY(-8px)',
          boxShadow: '0 15px 30px rgba(0,0,0,0.1)'
        }
      },
      managementCardHeader: {
        fontSize: '18px',
        fontWeight: '600',
        padding: '20px 24px',
        borderBottom: '1px solid #f0f0f0',
        color: '#2c3e50',
        backgroundColor: '#f8fafc'
      },
      managementCardImage: {
        height: '140px',
        background: 'linear-gradient(135deg, #f5f7fa 0%, #e4e8eb 100%)',
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        fontSize: '48px',
        color: '#7f8c8d',
        transition: 'all 0.3s ease'
      },
      managementCardBody: {
        padding: '20px 24px',
        flexGrow: 1,
        color: '#4a5568',
        fontSize: '14px',
        lineHeight: '1.6'
      },
      managementCardButton: {
        margin: '0 24px 24px',
        padding: '12px 0',
        border: 'none',
        borderRadius: '12px',
        backgroundColor: '#4a90e2',
        color: 'white',
        fontWeight: '600',
        fontSize: '14px',
        cursor: 'pointer',
        transition: 'all 0.3s ease',
        boxShadow: '0 4px 10px rgba(74, 144, 226, 0.3)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        gap: '8px',
        '&:hover': {
          backgroundColor: '#3a7bc8',
          transform: 'translateY(-2px)',
          boxShadow: '0 6px 15px rgba(74, 144, 226, 0.4)'
        }
      }
    };

    // Card component for counts
    const Card = ({ title, count, iconClass, index, subtitle }) => {
      const [hover, setHover] = useState(false);
      
      return (
        <div 
          style={{ 
            ...styles.card(index), 
            transform: hover ? 'translateY(-5px)' : 'none',
            boxShadow: hover ? '0 15px 30px rgba(0,0,0,0.15)' : '0 10px 20px rgba(0,0,0,0.1)'
          }}
          onMouseEnter={() => setHover(true)}
          onMouseLeave={() => setHover(false)}
        >
          <i className={iconClass} style={styles.cardIcon}></i>
          <div style={styles.cardContent}>
            <div style={styles.cardTitle}>{title}</div>
            <div style={styles.cardCount}>{count}</div>
            {subtitle && <div style={styles.cardSubtitle}>{subtitle}</div>}
          </div>
        </div>
      );
    };

    // Sidebar item
    const SidebarItem = ({ iconClass, label }) => {
      const active = selectedMenu === label;
      const [hover, setHover] = useState(false);
      
      return (
        <div
          style={{ 
            ...styles.sidebarItem(active),
            transform: hover && !active ? 'translateX(5px)' : 'none',
            backgroundColor: hover || active ? 'rgba(255,255,255,0.1)' : 'transparent'
          }}
          onClick={() => setSelectedMenu(label)}
          onMouseEnter={() => setHover(true)}
          onMouseLeave={() => setHover(false)}
        >
          <i className={iconClass} style={{ 
            ...styles.sidebarIcon,
            color: active ? '#4a90e2' : hover ? '#ffffff' : '#bdc3c7'
          }}></i>
          {label}
        </div>
      );
    };

    // Management Card
    const ManagementCard = ({ title, description, iconClass }) => {
      const [hover, setHover] = useState(false);
      
      return (
        <div
          style={hover ? { ...styles.managementCard, ...styles.managementCard[':hover'] } : styles.managementCard}
          onMouseEnter={() => setHover(true)}
          onMouseLeave={() => setHover(false)}
        >
          <div style={styles.managementCardHeader}>{title}</div>
          <div style={{
            ...styles.managementCardImage,
            color: hover ? '#4a90e2' : '#7f8c8d'
          }}>
            <i className={iconClass}></i>
          </div>
          <div style={styles.managementCardBody}>{description}</div>
          <button
            style={hover ? { 
              ...styles.managementCardButton, 
              backgroundColor: '#3a7bc8',
              transform: 'translateY(-2px)',
              boxShadow: '0 6px 15px rgba(74, 144, 226, 0.4)'
            } : styles.managementCardButton}
            onClick={() => alert(`Go to ${title}`)}
          >
            <i className="bi bi-arrow-right-circle"></i>
            Manage {title.split(' ')[0]}
          </button>
        </div>
      );
    };

    return (
      <div style={styles.container}>
        <div style={styles.sidebar}>
          <div style={styles.sidebarTitle}>
            <i className="bi bi-speedometer2"></i>
            Dashboard
          </div>
          <SidebarItem iconClass="bi bi-house-door" label="Home" />
          <SidebarItem iconClass="bi bi-people" label="Customers" />
          <SidebarItem iconClass="bi bi-box-seam" label="Products" />
          <SidebarItem iconClass="bi bi-receipt" label="Invoices" />
          <SidebarItem iconClass="bi bi-graph-up" label="Reports" />
          <SidebarItem iconClass="bi bi-gear" label="Settings" />
        </div>

        <div style={styles.mainContent}>
          <nav style={styles.navbar}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
              <i className="bi bi-speedometer2" style={{ color: '#4a90e2' }}></i>
              <span>Dashboard Overview</span>
            </div>
            <div style={styles.navbarUser}>
              <div style={styles.userAvatar}>AU</div>
              Admin User
              <button
                style={styles.logoutBtn}
                onClick={() => alert('Logging out')}
              >
                <i className="bi bi-box-arrow-right"></i>
                Logout
              </button>
            </div>
          </nav>

          <div style={styles.sectionTitle}>Key Metrics</div>
          <section style={styles.cardsRow}>
            <Card 
              title="Total Customers" 
              count={customerCount} 
              iconClass="bi bi-people" 
              index={0} 
              subtitle="+12% from last month" 
            />
            <Card 
              title="Today's Sales" 
              count={`$${todaySales}`} 
              iconClass="bi bi-currency-dollar" 
              index={1} 
              subtitle="+5 orders today" 
            />
            <Card 
              title="Due Bills" 
              count={dueBills} 
              iconClass="bi bi-receipt" 
              index={2} 
              subtitle="3 overdue" 
            />
            <Card 
              title="Products" 
              count={productsCount} 
              iconClass="bi bi-box-seam" 
              index={3} 
              subtitle="12 low in stock" 
            />
          </section>

          <div style={styles.sectionTitle}>Quick Access</div>
          <section style={styles.managementSection}>
            <ManagementCard
              title="Inventory Management"
              description="Keep track of your stock levels, update product info, and optimize inventory flow."
              iconClass="bi bi-inboxes"
            />
            <ManagementCard
              title="Sales Management"
              description="Monitor your sales data, generate invoices, and analyze customer purchases for better business decisions."
              iconClass="bi bi-cart"
            />
            <ManagementCard
              title="Customer Management"
              description="Manage customer relationships, view purchase history, and track customer preferences."
              iconClass="bi bi-people"
            />
          </section>
        </div>
      </div>
    );
};

export default Dashboard;