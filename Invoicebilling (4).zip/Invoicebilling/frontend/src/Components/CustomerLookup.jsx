import React, { useState, useEffect } from 'react';
import axios from 'axios';
import 'bootstrap-icons/font/bootstrap-icons.css';

const CustomerLookup = ({ setCustomer, resetTrigger }) => {
  const [phone, setPhone] = useState('');
  const [error, setError] = useState('');
  const [showAddForm, setShowAddForm] = useState(false);
  const [isExisting, setIsExisting] = useState(false);
  const [todayDate, setTodayDate] = useState('');


  const [newCustomer, setNewCustomer] = useState({
    customerId: '',
    cname: '',
    address: '',
    mailId: '',
    cphone: '',
    category: '',
    walletBal: ''
  });
  useEffect(() => {
    if (resetTrigger) {
      setPhone('');
      setError('');
      setShowAddForm(false);
      setIsExisting(false);
      setNewCustomer({
        customerId: '',
        cname: '',
        address: '',
        mailId: '',
        cphone: '',
        category: '',
        walletBal: ''
      });
    }
  }, [resetTrigger]);


  useEffect(() => {
    const today = new Date().toISOString().split('T')[0];
    setTodayDate(today);
  }, []);

  const handleSearch = async () => {
    try {
      const res = await axios.get(`http://localhost:5000/api/customers/search/${phone}`);
      if (res.data) {
        setCustomer(res.data);
        setNewCustomer(res.data);
        setError('');
        setIsExisting(true);
        setShowAddForm(true);
      } else {
        setError('Customer not found.');
        setShowAddForm(true);
        setIsExisting(false);
        setNewCustomer((prev) => ({ ...prev, cphone: phone }));
      }
    } catch (err) {
      setError('Customer Not Found');
      setShowAddForm(true);
      setIsExisting(false);
      setNewCustomer((prev) => ({ ...prev, cphone: phone }));
    }
  };

  const handleAddCustomer = async () => {
    try {
      const { cname, address, mailId, cphone, category } = newCustomer;
      const res = await axios.post('http://localhost:5000/api/customers/add', {
        cname, address, mailId, cphone, category
      });
      setCustomer(res.data.customer);
      setError('');
      setShowAddForm(false);
    } catch (err) {
      console.error('Error:', err.response?.data || err.message);
      setError('Error saving customer.');
    }
  };

  return (
    <div
      className="card shadow p-4 mb-5"
      style={{ backgroundColor: '#fdfdfd', borderRadius: '12px' }}
    >
      <div className="d-flex justify-content-between align-items-center mb-3">
        <h5 style={{ color: '#0d6efd', fontWeight: 'bold' }}>
          <i className="bi bi-person-lines-fill"></i> Customer Panel
        </h5>
        <div className="d-flex align-items-center">
          <label className="me-2 mb-0 fw-bold">Date:</label>
          <input
            type="date"
            className="form-control form-control-sm"
            value={todayDate}
            readOnly
            style={{ backgroundColor: '#e9ecef' }}
          />
        </div>
      </div>

      <div className="input-group mb-3">
        <input
          type="tel"
          className="form-control"
          placeholder="Enter Phone Number"
          value={phone}
          onChange={(e) => setPhone(e.target.value)}
        />
        <button className="btn btn-primary" onClick={handleSearch}>
          <i className="bi bi-search"></i> Search
        </button>
      </div>

      {error && <div className="alert alert-danger py-1">{error}</div>}

      {showAddForm && (
        <>
          <hr />
          <div className="row g-3">
            <div className="col-md-6">
              <label className="form-label fw-semibold">Customer ID</label>
              <input
                type="text"
                className="form-control"
                value={newCustomer.customerId || ''}
                disabled
                style={{ backgroundColor: '#e9ecef', fontWeight: 'bold' }}
              />
            </div>
            <div className="col-md-6">
              <label className="form-label fw-semibold">Name</label>
              <input
                type="text"
                className="form-control"
                value={newCustomer.cname}
                onChange={(e) => setNewCustomer({ ...newCustomer, cname: e.target.value })}
                disabled={isExisting}
                style={isExisting ? { backgroundColor: '#e9ecef' } : {}}
              />
            </div>
            <div className="col-md-6">
              <label className="form-label fw-semibold">Phone</label>
              <input
                type="tel"
                className="form-control"
                value={newCustomer.cphone}
                disabled
                style={{ backgroundColor: '#e9ecef' }}
              />
            </div>
            <div className="col-md-6">
              <label className="form-label fw-semibold">Email</label>
              <input
                type="email"
                className="form-control"
                value={newCustomer.mailId}
                onChange={(e) => setNewCustomer({ ...newCustomer, mailId: e.target.value })}
                disabled={isExisting}
                style={isExisting ? { backgroundColor: '#e9ecef' } : {}}
              />
            </div>
            <div className="col-md-6">
              <label className="form-label fw-semibold">Category</label>
              {isExisting ? (
                <input
                  type="text"
                  className="form-control"
                  value={newCustomer.category}
                  disabled
                  style={{ backgroundColor: '#e9ecef' }}
                />
              ) : (
                <select
                  className="form-select"
                  value={newCustomer.category}
                  onChange={(e) => setNewCustomer({ ...newCustomer, category: e.target.value })}
                >
                  <option value="">-- Select Category --</option>
                  <option value="Wholesaler">Wholesaler</option>
                  <option value="Retailer">Retailer</option>
                  <option value="Premium">Premium</option>
                </select>
              )}
            </div>

            <div className="col-md-6">
              <label className="form-label fw-semibold">Wallet Balance</label>
              <input
                type="text"
                className="form-control"
                value={newCustomer.walletBal}
                onChange={(e) => setNewCustomer({ ...newCustomer, walletBal: e.target.value })}
                disabled={isExisting}
                style={isExisting ? { backgroundColor: '#e9ecef' } : {}}
              />
            </div>
            <div className="col-12">
              <label className="form-label fw-semibold">Address</label>
              <textarea
                className="form-control"
                rows="2"
                value={newCustomer.address}
                onChange={(e) => setNewCustomer({ ...newCustomer, address: e.target.value })}
                disabled={isExisting}
                style={isExisting ? { backgroundColor: '#e9ecef' } : {}}
              ></textarea>
            </div>
          </div>

          {!isExisting && (
            <div className="mt-3 text-end">
              <button className="btn btn-success" onClick={handleAddCustomer}>
                <i className="bi bi-save"></i> Save & Continue Billing
              </button>
            </div>
          )}
        </>
      )}
    </div>
  );
};

export default CustomerLookup;
