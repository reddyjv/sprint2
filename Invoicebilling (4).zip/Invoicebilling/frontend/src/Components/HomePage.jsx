// src/components/HomePage.jsx
import { useNavigate } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import './HomePage.css';
import inventoryImg from '../assets/OIP.jpg';
import salesImg from '../assets/sales.jpg';
import ManNavbar from "../Components/ManNavbar"

const HomePage = () => {
  const navigate = useNavigate();

  return (
    <div className="d-flex flex-column min-vh-100 homepage-container">
      {/* Navbar */}
      <ManNavbar/>

      {/* Main Content */}
      <div className="container flex-grow-1 d-flex align-items-center justify-content-center my-5">
        <div className="row w-100 g-4">
          <div className="col-md-6 d-flex justify-content-center">
            <div className="card custom-card text-center">
              <div className="card-body">
                <img src={inventoryImg} alt="Inventory" className="card-img-top custom-card-img mb-3" />
                <h5 className="card-title">📦 Inventory Management</h5>
                <p className="card-text">Manage your product list, stock, and pricing.</p>
                <button className="btn btn-inventory" onClick={() => navigate('/ManagerHome')}>
                  Go to Inventory
                </button>
              </div>
            </div>
          </div>

          <div className="col-md-6 d-flex justify-content-center">
            <div className="card custom-card text-center">
              <div className="card-body">
                <img src={salesImg} alt="Sales" className="card-img-top custom-card-img mb-3" />
                <h5 className="card-title">💰 Sales Management</h5>
                <p className="card-text">Track customer orders and sales records.</p>
                <button className="btn btn-sales" onClick={() => navigate('/sales')}>
                  Go to Sales
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="custom-footer text-light text-center py-3">
        <small>&copy; 2025 Business App. All rights reserved.</small>
      </footer>
    </div>
  );
};

export default HomePage;
