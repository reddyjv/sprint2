import { useState } from 'react';
import axios from 'axios';
import 'bootstrap/dist/css/bootstrap.min.css';
import { useNavigate } from 'react-router';
import ManNavbar from './ManNavbar';

const AddProductForm = () => {
  const [formData, setFormData] = useState({
    pname: '',
    saleprice: '',
    MRP: '',
    stock: '',
    GST: '',
    batchNo: '',
    category: '',
  });

  const [formErrors, setFormErrors] = useState({
    pname: '',
    saleprice: '',
    MRP: '',
    stock: '',
    GST: '',
    batchNo: '',
    category: '',
  });

  const [formValid, setFormValid] = useState({
    pname: false,
    saleprice: false,
    MRP: false,
    stock: false,
    GST: false,
    batchNo: false,
    category: false,
  });

  const navigate = useNavigate();
  const categories = ['Groceries', 'Fashion', 'Beauty Products', 'Electronics', 'Pharmacy'];

  // Validate field based on name and value
  const validateField = (fieldName, value) => {
    let error = '';
    let isValid = false;

    switch (fieldName) {
      case 'pname':
        isValid = /^[A-Za-z0-9\s]{2,50}$/.test(value);
        error = isValid ? '' : 'Product name should be 2-50 characters.';
        setFormErrors(prev => ({ ...prev, pname: error }));
        setFormValid(prev => ({ ...prev, pname: isValid }));
        break;

      case 'saleprice':
        isValid = /^\d+(\.\d{1,2})?$/.test(value) && parseFloat(value) >= 0;
        error = isValid ? '' : 'Enter a valid non-negative number.';
        setFormErrors(prev => ({ ...prev, saleprice: error }));
        setFormValid(prev => ({ ...prev, saleprice: isValid }));
        break;

      case 'MRP':
        isValid = /^\d+(\.\d{1,2})?$/.test(value) && parseFloat(value) >= 0;
        error = isValid ? '' : 'Enter a valid non-negative number.';
        setFormErrors(prev => ({ ...prev, MRP: error }));
        setFormValid(prev => ({ ...prev, MRP: isValid }));
        break;

      case 'stock':
        isValid = /^\d+$/.test(value) && parseInt(value) >= 0;
        error = isValid ? '' : 'Enter a valid non-negative integer.';
        setFormErrors(prev => ({ ...prev, stock: error }));
        setFormValid(prev => ({ ...prev, stock: isValid }));
        break;

      case 'GST':
        isValid = /^\d+(\.\d{1,2})?$/.test(value) && parseFloat(value) >= 0;
        error = isValid ? '' : 'Enter a valid non-negative number.';
        setFormErrors(prev => ({ ...prev, GST: error }));
        setFormValid(prev => ({ ...prev, GST: isValid }));
        break;

      case 'batchNo':
        isValid = /^[A-Za-z0-9]{3,20}$/.test(value);
        error = isValid ? '' : 'Batch number must be alphanumeric (3-20 chars).';
        setFormErrors(prev => ({ ...prev, batchNo: error }));
        setFormValid(prev => ({ ...prev, batchNo: isValid }));
        break;

      case 'category':
        isValid = value !== '';
        error = isValid ? '' : 'Category is required.';
        setFormErrors(prev => ({ ...prev, category: error }));
        setFormValid(prev => ({ ...prev, category: isValid }));
        break;

      default:
        break;
    }
  };

  // Handle input change with separate cases, no dynamic keys in setFormData
const handleChange = (e) => {
  const { name, value } = e.target;
  setFormData(prev => ({ ...prev, [name]: value }));
  validateField(name, value);
};

  const isButtonActive =
    formValid.pname &&
    formValid.saleprice &&
    formValid.MRP &&
    formValid.stock &&
    formValid.GST &&
    formValid.batchNo &&
    formValid.category;

  const handleSubmit = async e => {
    e.preventDefault();
    if (!isButtonActive) return;

    try {
      const response = await axios.post('http://localhost:5000/api/products/add', formData);
      alert('✅ Product added with ID: ' + response.data.product.productId);
      navigate('/managerHome');
    } catch (error) {
      alert('❌ Error adding product');
      console.error(error);
    }
  };

  return (
    <>
      <ManNavbar />
      <div className="container mt-5">
        <div className="card shadow-lg p-4 bg-light" style={{ maxWidth: '650px', margin: '0 auto' }}>
          <h3 className="card-title mb-4 text-center text-primary">🛍️ Add New Product</h3>
          <form onSubmit={handleSubmit}>
            <div className="mb-3">
              <label htmlFor="pname" className="form-label fw-semibold">Product Name</label>
              <input
                type="text"
                className={`form-control ${formErrors.pname ? 'is-invalid' : ''}`}
                id="pname"
                name="pname"
                value={formData.pname}
                onChange={handleChange}
                placeholder="Enter product name"
              />
              {formErrors.pname && <div className="invalid-feedback">{formErrors.pname}</div>}
            </div>

            <div className="mb-3">
              <label htmlFor="saleprice" className="form-label fw-semibold">Sale Price (₹)</label>
              <input
                type="number"
                className={`form-control ${formErrors.saleprice ? 'is-invalid' : ''}`}
                id="saleprice"
                name="saleprice"
                value={formData.saleprice}
                onChange={handleChange}
                placeholder="Enter sale price"
                min="0"
                step="0.01"
              />
              {formErrors.saleprice && <div className="invalid-feedback">{formErrors.saleprice}</div>}
            </div>

            <div className="mb-3">
              <label htmlFor="MRP" className="form-label fw-semibold">MRP (₹)</label>
              <input
                type="number"
                className={`form-control ${formErrors.MRP ? 'is-invalid' : ''}`}
                id="MRP"
                name="MRP"
                value={formData.MRP}
                onChange={handleChange}
                placeholder="Enter MRP"
                min="0"
                step="0.01"
              />
              {formErrors.MRP && <div className="invalid-feedback">{formErrors.MRP}</div>}
            </div>

            <div className="mb-3">
              <label htmlFor="stock" className="form-label fw-semibold">Stock</label>
              <input
                type="number"
                className={`form-control ${formErrors.stock ? 'is-invalid' : ''}`}
                id="stock"
                name="stock"
                value={formData.stock}
                onChange={handleChange}
                placeholder="Enter stock quantity"
                min="0"
                step="1"
              />
              {formErrors.stock && <div className="invalid-feedback">{formErrors.stock}</div>}
            </div>

            <div className="mb-3">
              <label htmlFor="GST" className="form-label fw-semibold">GST (%)</label>
              <input
                type="number"
                className={`form-control ${formErrors.GST ? 'is-invalid' : ''}`}
                id="GST"
                name="GST"
                value={formData.GST}
                onChange={handleChange}
                placeholder="Enter GST percentage"
                min="0"
                step="0.01"
              />
              {formErrors.GST && <div className="invalid-feedback">{formErrors.GST}</div>}
            </div>

            <div className="mb-3">
              <label htmlFor="batchNo" className="form-label fw-semibold">Batch Number</label>
              <input
                type="text"
                className={`form-control ${formErrors.batchNo ? 'is-invalid' : ''}`}
                id="batchNo"
                name="batchNo"
                value={formData.batchNo}
                onChange={handleChange}
                placeholder="Enter batch number"
              />
              {formErrors.batchNo && <div className="invalid-feedback">{formErrors.batchNo}</div>}
            </div>

            <div className="mb-4">
              <label htmlFor="category" className="form-label fw-semibold">Category</label>
              <select
                className={`form-select ${formErrors.category ? 'is-invalid' : ''}`}
                id="category"
                name="category"
                value={formData.category}
                onChange={handleChange}
              >
                <option value="">Select Category</option>
                {categories.map(cat => (
                  <option key={cat} value={cat}>{cat}</option>
                ))}
              </select>
              {formErrors.category && <div className="invalid-feedback">{formErrors.category}</div>}
            </div>

            <div className="d-grid">
              <button type="submit" className="btn btn-primary fw-bold" disabled={!isButtonActive}>
                ➕ Add Product
              </button>
            </div>
          </form>
        </div>
      </div>
    </>
  );
};

export default AddProductForm;
