import React, { useEffect, useState } from 'react';
import BillingSummary from './BillingSummary';
import axios from 'axios';

const ProductEntry = ({ customer, onResetAll }) => {
  const [availableProducts, setAvailableProducts] = useState([]);
  const [entries, setEntries] = useState([createEmptyEntry()]);
  const [showSummary, setShowSummary] = useState(false);
  const [isDisabled, setIsDisabled] = useState(false);
  const customers = customer;

  function createEmptyEntry() {
    return {
      pname: '',
      qty: 1,
      saleprice: 0,
      GST: 0,
      discount: 0,
      batchNo: '',
      MRP: 0,
      category: ''
    };
  }

  useEffect(() => {
    const loadProducts = async () => {
      try {
        const response = await axios.get('http://localhost:5000/api/products');
        setAvailableProducts(response.data);
      } catch (error) {
        console.error('Error fetching products:', error);
      }
    };
    loadProducts();
  }, []);

  const handleChange = (index, key, value) => {
    const newEntries = [...entries];
    newEntries[index][key] = key === 'pname' ? value : parseFloat(value) || 0;
    setEntries(newEntries);
  };

  const handleSelect = (index, pname) => {
    const selected = availableProducts.find(p => p.pname === pname);
    if (selected) {
      const updated = {
        ...entries[index],
        pname: selected.pname,
        saleprice: selected.saleprice,
        GST: selected.GST,
        MRP: selected.MRP,
        batchNo: selected.batchNo,
        category: selected.category,
        discount: 0
      };
      const newEntries = [...entries];
      newEntries[index] = updated;
      setEntries(newEntries);
    }
  };

  const handleAddMore = () => {
    setEntries([...entries, createEmptyEntry()]);
  };

  const handleDeleteRow = (index) => {
    const newEntries = entries.filter((_, i) => i !== index);
    setEntries(newEntries);
  };

  const handleCalculateBill = () => {
    setShowSummary(true);
    setIsDisabled(true);
  };

  const handleReset = () => {
    setEntries([createEmptyEntry()]);
    setShowSummary(false);
    setIsDisabled(false);
    if (onResetAll) onResetAll();
  };

  // Modern styling
  const styles = {
    container: {
      backgroundColor: '#ffffff',
      borderRadius: '16px',
      boxShadow: '0 8px 32px rgba(0, 0, 0, 0.08)',
      padding: '32px',
      maxWidth: '1600px'
    },
    header: {
      color: '#2d3748',
      fontWeight: '700',
      fontSize: '24px',
      marginBottom: '28px',
      textAlign: 'center',
      position: 'relative',
      paddingBottom: '16px'
    },
    headerUnderline: {
      content: '""',
      position: 'absolute',
      bottom: '0',
      left: '50%',
      transform: 'translateX(-50%)',
      width: '80px',
      height: '4px',
      background: 'linear-gradient(90deg, #667eea 0%, #764ba2 100%)',
      borderRadius: '2px'
    },
    
    table: {
      width: '100%',
      borderCollapse: 'separate',
      borderSpacing: '0 12px'
    },
    tableHeader: {
      backgroundColor: '#f8fafc',
      color: '#4a5568',
      fontWeight: '600',
      fontSize: '14px',
      textTransform: 'uppercase',
      letterSpacing: '0.5px'
    },
    tableRow: {
      backgroundColor: '#ffffff',
      borderRadius: '12px',
      boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.05)',
      transition: 'all 0.2s ease',
      '&:hover': {
        boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.1)'
      }
    },
    tableCell: {
      padding: '16px',
      verticalAlign: 'middle',
      border: 'none'
    },
    select: {
      backgroundColor: '#ffffff',
      border: '1px solid #e2e8f0',
      borderRadius: '8px',
      padding: '10px 12px',
      fontSize: '14px',
      color: '#2d3748',
      width: '100%',
      transition: 'all 0.2s ease',
      '&:focus': {
        borderColor: '#667eea',
        boxShadow: '0 0 0 3px rgba(102, 126, 234, 0.1)'
      }
    },
    input: {
      backgroundColor: '#ffffff',
      border: '1px solid #e2e8f0',
      borderRadius: '8px',
      padding: '10px 12px',
      fontSize: '14px',
      color: '#2d3748',
      width: '100%',
      transition: 'all 0.2s ease',
      '&:focus': {
        borderColor: '#667eea',
        boxShadow: '0 0 0 3px rgba(102, 126, 234, 0.1)'
      }
    },
    disabledInput: {
      backgroundColor: '#f8fafc',
      border: '1px solid #e2e8f0',
      color: '#a0aec0'
    },
    buttonGroup: {
      display: 'flex',
      justifyContent: 'space-between',
      marginTop: '24px',
      gap: '16px'
    },
    primaryButton: {
      backgroundColor: '#667eea',
      color: 'white',
      border: 'none',
      borderRadius: '10px',
      padding: '12px 24px',
      fontWeight: '600',
      fontSize: '14px',
      cursor: 'pointer',
      transition: 'all 0.2s ease',
      display: 'flex',
      alignItems: 'center',
      gap: '8px',
      '&:hover': {
        backgroundColor: '#5a67d8',
        transform: 'translateY(-2px)'
      },
      '&:disabled': {
        backgroundColor: '#c3dafe',
        cursor: 'not-allowed'
      }
    },
    successButton: {
      backgroundColor: '#48bb78',
      color: 'white',
      border: 'none',
      borderRadius: '10px',
      padding: '12px 24px',
      fontWeight: '600',
      fontSize: '14px',
      cursor: 'pointer',
      transition: 'all 0.2s ease',
      display: 'flex',
      alignItems: 'center',
      gap: '8px',
      '&:hover': {
        backgroundColor: '#38a169',
        transform: 'translateY(-2px)'
      },
      '&:disabled': {
        backgroundColor: '#9ae6b4',
        cursor: 'not-allowed'
      }
    },
    dangerButton: {
      backgroundColor: '#f56565',
      color: 'white',
      border: 'none',
      borderRadius: '6px',
      padding: '8px 12px',
      fontWeight: '500',
      fontSize: '12px',
      cursor: 'pointer',
      transition: 'all 0.2s ease',
      display: 'flex',
      alignItems: 'center',
      gap: '4px',
      '&:hover': {
        backgroundColor: '#e53e3e'
      },
      '&:disabled': {
        backgroundColor: '#fed7d7',
        cursor: 'not-allowed'
      }
    }
  };

  return (
    <div style={styles.container}>
      <div style={styles.header}>
        Product Billing Panel
        <div style={styles.headerUnderline}></div>
      </div>

      <div style={{ overflowX: 'auto' }}>
        <table style={styles.table}>
          <thead>
            <tr style={styles.tableHeader}>
              <th style={{ ...styles.tableCell, borderTopLeftRadius: '8px', borderBottomLeftRadius: '8px' }}>Product</th>
              <th style={styles.tableCell}>Qty</th>
              <th style={styles.tableCell}>Sale Price</th>
              <th style={styles.tableCell}>MRP</th>
              <th style={styles.tableCell}>GST %</th>
              <th style={styles.tableCell}>Discount</th>
              <th style={styles.tableCell}>Batch No</th>
              <th style={styles.tableCell}>Category</th>
              <th style={{ ...styles.tableCell, borderTopRightRadius: '8px', borderBottomRightRadius: '8px' }}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {entries.map((entry, index) => (
              <tr key={index} style={styles.tableRow}>
                <td style={{ ...styles.tableCell, borderTopLeftRadius: '12px', borderBottomLeftRadius: '12px' }}>
                  <select
                    style={styles.select}
                    value={entry.pname}
                    onChange={(e) => handleSelect(index, e.target.value)}
                    disabled={isDisabled}
                  >
                    <option value="">Select Product</option>
                    {availableProducts
                      .filter(p =>
                        !entries.some((e, i) => e.pname === p.pname && i !== index)
                      )
                      .map((p) => (
                        <option key={p.productId} value={p.pname}>
                          {p.pname}
                        </option>
                      ))}
                  </select>
                </td>
                <td style={styles.tableCell}>
                  <input
                    type="number"
                    style={styles.input}
                    min="1"
                    value={entry.qty}
                    onChange={(e) => handleChange(index, 'qty', e.target.value)}
                    disabled={isDisabled}
                  />
                </td>
                <td style={styles.tableCell}>
                  <input
                    type="number"
                    style={{ ...styles.input, ...styles.disabledInput }}
                    value={entry.saleprice}
                    disabled
                  />
                </td>
                <td style={styles.tableCell}>
                  <input
                    type="number"
                    style={{ ...styles.input, ...styles.disabledInput }}
                    value={entry.MRP}
                    disabled
                  />
                </td>
                <td style={styles.tableCell}>
                  <input
                    type="number"
                    style={{ ...styles.input, ...styles.disabledInput }}
                    value={entry.GST}
                    disabled
                  />
                </td>
                <td style={styles.tableCell}>
                  <input
                    type="number"
                    style={styles.input}
                    min="0"
                    value={entry.discount}
                    onChange={(e) => handleChange(index, 'discount', e.target.value)}
                    disabled={isDisabled}
                  />
                </td>
                <td style={styles.tableCell}>
                  <input
                    type="text"
                    style={{ ...styles.input, ...styles.disabledInput }}
                    value={entry.batchNo}
                    disabled
                  />
                </td>
                <td style={styles.tableCell}>
                  <input
                    type="text"
                    style={{ ...styles.input, ...styles.disabledInput }}
                    value={entry.category}
                    disabled
                  />
                </td>
                <td style={{ ...styles.tableCell, borderTopRightRadius: '12px', borderBottomRightRadius: '12px' }}>
                  <button
                    type="button"
                    style={styles.dangerButton}
                    onClick={() => handleDeleteRow(index)}
                    disabled={isDisabled}
                  >
                    <i className="bi bi-trash"></i>
                    Remove
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div style={styles.buttonGroup}>
        <button
          style={styles.primaryButton}
          onClick={handleAddMore}
          disabled={isDisabled}
        >
          <i className="bi bi-plus-circle"></i>
          Add Product
        </button>
        <button
          style={styles.successButton}
          onClick={handleCalculateBill}
          disabled={isDisabled}
        >
          <i className="bi bi-calculator"></i>
          Calculate Bill
        </button>
      </div>

      {showSummary && <BillingSummary products={entries} customer={customers} onReset={handleReset} />}
    </div>
  );
};

export default ProductEntry;