// src/components/Navbar.jsx
import { NavLink, useNavigate } from 'react-router-dom';
import { FaUserCircle } from 'react-icons/fa';
import 'bootstrap/dist/css/bootstrap.min.css';
import './navbar.css';  // Add custom styles here

const Navbar = () => {
  const navigate = useNavigate();

  return (
    <div className="d-flex flex-column min-vh-100 navbar-container">
      {/* Navbar */}
      <nav className="navbar navbar-expand-lg navbar-dark custom-navbar px-3">
        <NavLink className="navbar-brand fw-bold" to="/">🚀 Invoice App</NavLink>
        <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
          <span className="navbar-toggler-icon"></span>
        </button>
        <div className="collapse navbar-collapse" id="navbarNav">
          <ul className="navbar-nav ms-auto">
            <li className="nav-item"><NavLink className="nav-link" to="/user">Home</NavLink></li>
            <li className="nav-item"><NavLink className="nav-link" to="/add-product">Add Product</NavLink></li>
            <li className="nav-item"><NavLink className="nav-link" to="/products">List Products</NavLink></li>
            <li className="nav-item"><NavLink className="nav-link" to="/add-customer">Add Customer</NavLink></li>
            <li className="nav-item"><NavLink className="nav-link" to="/customers">List Customers</NavLink></li>
            <li className="nav-item"><NavLink className="nav-link" to="/profile"><FaUserCircle size={24} /> Profile</NavLink></li>
          </ul>
        </div>
      </nav>

      {/* Cards Section */}
      <div className="container my-5">
        <div className="row g-4 justify-content-center">
          <div className="col-md-6">
            <div className="custom-card text-center h-100">
              <div className="card-body">
                <h5 className="card-title">📦 Products List</h5>
                <p className="card-text">Track customer orders, billing, and sales analytics.</p>
                <button className="btn btn-primary" onClick={() => navigate('/products')}>View Products</button>
              </div>
            </div>
          </div>

          <div className="col-md-6">
            <div className="custom-card text-center h-100">
              <div className="card-body">
                <h5 className="card-title">➕ Add Product</h5>
                <p className="card-text">Quickly add new items to your inventory database.</p>
                <button className="btn btn-warning text-white" onClick={() => navigate('/add-product')}>Add Product</button>
              </div>
            </div>
          </div>

          <div className="col-md-6">
            <div className="custom-card text-center h-100">
              <div className="card-body">
                <h5 className="card-title">👤 Add Customer</h5>
                <p className="card-text">Register new customers and manage customer info.</p>
                <button className="btn btn-info text-white" onClick={() => navigate('/add-customer')}>Add Customer</button>
              </div>
            </div>
          </div>

          <div className="col-md-6">
            <div className="custom-card text-center h-100">
              <div className="card-body">
                <h5 className="card-title">📃 List Customers</h5>
                <p className="card-text">View all registered customers in your system.</p>
                <button className="btn btn-secondary" onClick={() => navigate('/customers')}>View Customers</button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="footer mt-auto text-white text-center py-3">
        <small>&copy; 2025 Invoice App</small>
      </footer>
    </div>
  );
};

export default Navbar;
