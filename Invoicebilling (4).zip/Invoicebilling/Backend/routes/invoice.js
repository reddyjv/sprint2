// routes/invoice.js
const express = require('express');
const router = express.Router();
const Invoice = require('../models/Invoices');

function generateInvoiceNumber(lastNumber) {
  if (!lastNumber) return 'INV1000';
  const num = parseInt(lastNumber.replace('INV', ''), 10) + 1;
  return `INV${num}`;
}

router.post('/createinvoice', async (req, res) => {
  try {
    const lastInvoice = await Invoice.findOne().sort({ _id: -1 });
    const newInvoiceNumber = generateInvoiceNumber(lastInvoice?.invoiceNumber);

    const now = new Date();
    const date = now.toLocaleDateString();
    const time = now.toLocaleTimeString();

    const invoice = new Invoice({
      invoiceNumber: newInvoiceNumber,
      date,
      time,
      customer: req.body.customer,
      items: req.body.items,
      totals: req.body.totals,
    });

    await invoice.save();
    res.status(201).json({ success: true, invoiceNumber: newInvoiceNumber, date, time });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

router.get('/all', async (req, res) => {
  try {
    const invoices = await Invoice.find().sort({ date: -1 });
    res.json(invoices);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Error fetching invoices' });
  }
});

// Assuming you are using Express and your Invoice model is imported
router.get('/totals/today', async (req, res) => {
  try {
    const today = new Date();
    const dd = String(today.getDate());        // No leading zero because you have format like "20/5/2025"
    const mm = String(today.getMonth() + 1);   // Same here
    const yyyy = today.getFullYear();

    // Format as DD/MM/YYYY — note no leading zeros as in your example "20/5/2025"
    const todayStr = `${dd}/${mm}/${yyyy}`;

    const result = await Invoice.aggregate([
      { $match: { date: todayStr } },
      {
        $group: {
          _id: null,
          totalSales: { $sum: "$totals.finalAmount" }
        }
      }
    ]);

    const totalSales = result.length > 0 ? result[0].totalSales : 0;
    console.log("Total Sale is ", totalSales);

    res.json({
      date: todayStr,
      totalSales
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Error fetching today total sales' });
  }
});


router.get('/due', async (req, res) => {
  try {
    const creditBills = await Invoice.find({ "totals.paymentMode": "credit" });
    res.json(creditBills);
  } catch (error) {
    console.error('Error fetching credit bills:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

module.exports = router;
