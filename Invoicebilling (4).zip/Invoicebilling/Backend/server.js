const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const nodemailer = require("nodemailer");
const multer = require('multer');
const fs = require('fs');

const app = express();
app.use(cors());
app.use(express.json());

mongoose.connect('mongodb://localhost:27017/invoicebilling')

// app.use('/api/auth', require('./routes/auth'));
app.use('/api/products', require('./routes/products'));
app.use('/api/customers', require('./routes/customers'));
app.use('/api/invoices',require('./routes/invoice'));
app.use('/api/users',require('./routes/Users'))


const upload = multer({ dest: 'uploads/' });

app.post('/send-invoice', upload.single('pdf'), async (req, res) => {
  try {
    const { email } = req.body;
    const filePath = req.file.path;

    const transporter = nodemailer.createTransport({
      service: 'gmail',
      auth: {
        user: 'spprtnvcng@gmail.com',
        pass: 'sjkr dcfy cael leiw',
      },
    });

    const mailOptions = {
      from: 'spprtnvcng@gmail.com',
      to: email,
      subject: 'Your Invoice',
      text: 'Please find your invoice attached.',
      attachments: [
        {
          filename: req.file.originalname || 'invoice.pdf',
          path: filePath,
        },
      ],
    };

    await transporter.sendMail(mailOptions);

    fs.unlinkSync(filePath); // Delete file after sending
    res.status(200).json({ message: 'Invoice emailed successfully.' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Failed to send invoice.' });
  }
});

app.post('/send-reminder', async (req, res) => {
  const {
    invoiceNumber,
    date,
    time,
    customerName,
    customerEmail,
    customerPhone,
    amount,
    paymentMode,
  } = req.body;

  if (!customerEmail) {
    return res.status(400).json({ message: 'Customer email is required' });
  }

  const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
      user: 'spprtnvcng@gmail.com',
      pass: 'sjkr dcfy cael leiw',
    },
  });

  const htmlContent = `
    <div style="font-family: Arial, sans-serif;">
      <h2 style="color: #2a9d8f;">Payment Reminder</h2>
      <p>Dear ${customerName || 'Customer'},</p>
      <p>This is a friendly reminder that your payment is due for the following invoice:</p>
      <table style="border-collapse: collapse; width: 100%;">
        <tr><td><strong>Invoice Number:</strong></td><td>${invoiceNumber}</td></tr>
        <tr><td><strong>Date:</strong></td><td>${date}</td></tr>
        <tr><td><strong>Time:</strong></td><td>${time}</td></tr>
        <tr><td><strong>Customer Phone:</strong></td><td>${customerPhone}</td></tr>
        <tr><td><strong>Amount Due:</strong></td><td><strong style="color:red;">₹${amount?.toFixed(2)}</strong></td></tr>
        <tr><td><strong>Payment Mode:</strong></td><td>${paymentMode}</td></tr>
      </table>
      <p>Please clear your dues at the earliest convenience.</p>
      <br/>
      <p>Thank you,<br/><strong>Your Company Name</strong></p>
    </div>
  `;

  const mailOptions = {
    from: 'spprtnvcng@gmail.com',
    to: customerEmail,
    subject: 'Payment Reminder - Invoice ' + invoiceNumber,
    html: htmlContent,
  };

  try {
    await transporter.sendMail(mailOptions);
    res.status(200).json({ message: 'Reminder email sent successfully' });
  } catch (error) {
    console.error('Error sending reminder email:', error);
    res.status(500).json({ message: 'Failed to send reminder email' });
  }
});

app.listen(5000, () => console.log('Server running on port 5000'));
